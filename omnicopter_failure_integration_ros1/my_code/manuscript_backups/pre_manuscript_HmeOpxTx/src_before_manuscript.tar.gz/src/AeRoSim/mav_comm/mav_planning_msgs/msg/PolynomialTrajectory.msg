Header header
PolynomialSegment[] segments
